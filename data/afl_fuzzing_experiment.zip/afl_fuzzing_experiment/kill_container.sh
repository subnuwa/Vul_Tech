#!/bin/bash

DID=$(echo $paswd | sudo -S docker ps -a -q)

paswd="fwq2018"

echo "------------------"
for did in $DID
do
	echo $paswd | sudo -S docker rm -f $did
	echo "stop container $did"
done
echo "------------------"

