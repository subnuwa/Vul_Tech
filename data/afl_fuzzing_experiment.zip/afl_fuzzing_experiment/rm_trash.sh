#!/bin/bash

path=$(pwd)
for i in $(seq 1 10)
do 
	cd "$path"/node"$i"
	cd log
	rm *
	cd ../records
	rm -rf *
	echo "node'$i' cleaned"
	sleep 1
done
