#!/bin/bash

ID=`ps -ef | grep "bash ./shell_test" | grep -v "grep" | awk '{print $2}'`

echo "-------------------"

for id in $ID
do
	kill -9 $id
	echo "kill $id"
done

echo "-------------------"


