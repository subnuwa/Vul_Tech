#!/bin/bash 

paswd="fwq2018"

echo $paswd  | sudo -S docker run -it --rm --cpus=10 --privileged -v /home/esco/Desktop/afl_fuzzing_experiment:/fuzzing --name "experiment" -h "experiment" vvendetta/aflfast bash /bin/bash



