#!/bin/bash

paswd="fwq2018"

for i in $(seq 1 2)
do 
	nohup bash ./scripts/start_node.sh $i >> ./nohup/node"$i".log 2>&1 &
	echo "activate node"$i

	sleep 3
done
