#/bin/bash

AFL_NO_FORKSRV=1 /aflfast/afl-fuzz -i /fuzzing/node"$2"/input -o /fuzzing/node"$2"/records/"$1"_out -m 1G -Q /fuzzing/node"$2"/binary/$1
