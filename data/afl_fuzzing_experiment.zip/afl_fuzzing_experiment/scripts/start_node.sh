#!/bin/bash


paswd="fwq2018"

crash_flag=0
run_time=0
interval=300

inputfiles=$(ls /fuzzing/node"$1"/binary) # get all the test cases

for inputname in $inputfiles
do
	echo "==================================="
	echo "input name : $inputname" 
	nohup bash /fuzzing/scripts/start_aflfast.sh $inputname $1 >> /fuzzing/node"$1"/log/"$inputname".log 2>&1  &	

	while [ $run_time -lt 86400 -a $crash_flag -eq 0 ]
	do 
		sleep $interval
		let 'run_time=run_time+interval'
		echo -ne "runtime :$run_time\\r"

		for crash_file in $(ls /fuzzing/node"$1"/records/"$inputname"_out/crashes)
		do
			if [ "${crash_file##*.}"x != "txt"x ]
			then 
				echo "crash found"
				let "crash_flag=1"
				break
				#ret=$(echo $paswd |sudo -S docker exec -i $inputname python ./fuzzing/scripts/Verify_Fuzzing_Input.py -i ./fuzzing/records/"$inputname"_out/crashes/$crash_file -t /fuzzing/track/"$inputname".txt)
				#echo $ret
				#if [ $ret = "True" ]
				#then
				#	echo "crash found"
				#	let "crash_flag=1"
				#	break
				#fi
			fi
		done
		
	done
	
	chmod -R 777 /fuzzing/node"$1"/records/"$inputname"_out 

	#bash /fuzzing/scripts/get_kill.sh $inputname
	PID=$(ps -ef | grep "$inputname" | grep -v "grep" | awk '{print $2}')

	echo "---------------"
	for id in $PID
	do
		kill -9 $id
		echo "killed $id"
	done
	echo "--------------"

	echo "run_time : $run_time"
	echo "==================================="
	let "run_time=0"
	let "crash_flag=0"

done
